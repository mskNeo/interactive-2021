window.addEventListener('load', () => {
  if (window.location.href.includes("https://www.google.com/search?")) {
    const links = document.querySelectorAll("a");
    let s = [];

    links.forEach(link => {
      if (link.href != '' && !link.href.includes('google.com')) {
        s.push(link.href);
      }
    });
    
    let sites = [...new Set(s)];  // remove duplicate links

    sites.splice(30); // limit links to only the first 30 links

    if (sites.length > 0) {
      sites.forEach((site) => {
        console.log(site);
        window.open(site, "_blank");
      });
    }
  }
});

